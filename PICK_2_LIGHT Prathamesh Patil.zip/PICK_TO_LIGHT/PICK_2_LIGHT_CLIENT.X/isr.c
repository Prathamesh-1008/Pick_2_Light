#include <xc.h>
#include "isr.h"

extern unsigned char wake,RX_flag,U_flag,swap_flag,flag,call;
extern unsigned char enter_flag;
extern unsigned char interrupt_flag;
void __interrupt() isr(void)
{
	if (INT0F == 1)
	{
        if(swap_flag==0)
        {
            RX_flag=!RX_flag;
            if(RX_flag==0)
            {
                call=0;
                flag=0;
                enter_flag=0;
            }
            else
            {
                call=1;
                enter_flag=1;    
                U_flag=0;
            }
        }
        else if(enter_flag==1 || enter_flag==2)
        {
            interrupt_flag=!interrupt_flag;
        }
        else
            wake = !wake;
            
		INT0F = 0;
	}
}
