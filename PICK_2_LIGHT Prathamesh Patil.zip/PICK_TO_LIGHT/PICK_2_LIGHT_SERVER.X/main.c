/*
Name : Prathamesh Patil
Date : 15/12/2024
Description : Pick to Light Server(Part)
*/
#include <xc.h>
#include "main.h"
#include "uart.h"
#include"can.h"

unsigned char ch;
unsigned char tx[9];
    
void __interrupt() isr(void)                   // Isr function called
{
    if (RCIF == 1)
    {
        if (OERR == 1)
            OERR = 0;
        
        ch = RCREG;
        RCIF = 0;
    }   
    
}
void init_config(void)
{
	init_uart();
    init_can();
	 /* Enabling peripheral interrupt */
   PEIE = 1;
    //init_can();
    /* Enabling global interrupt */
   GIE = 1;
}

void main()
{
	char c;

	init_config();
    char flag=1,count;                                 // declaration of the variables
	while (1)
	{
        if(can_receive())                            // data received is printing of the display through the UART
        {
            puts("\n\rRECEIVED DATA:\nID :-");
            for(int i=0;i<8;i++)
            {
                if(i<4)
                {
                    putch(can_payload[D0+i]+48);
                    if(i==3)
                        puts(" U_ST:- ");
                }
                else
                {
                    putch(can_payload[D0+i]+48);
                    if(i==7)    
                        puts("\n\r");
                }
            }
            flag=1;
        }
        else if(flag==1)
        {
            puts("Enter the PRODUCT-ID [NOTE : Max 4 Digits(Extra Digits will be Transcated)] :- ");
            flag=0;
            count=0;
        }
		else if (ch != '\0' && flag==0)
        {
            if(ch==0)
            {
                flag=1;
                ch='\0';
                continue;
            }
            else if(ch=='\r')
            {
                flag=2;
                if(count==1)
                {
                    tx[3]=tx[0];
                    tx[2]='0';
                    tx[1]='0';
                    tx[0]='0';                           // When the UART interrupt occur we are going to store the value
                }
                else if(count==2)
                {
                    tx[3]=tx[1];
                    tx[2]=tx[0];
                    tx[1]='0';
                    tx[0]='0';
                }
                else if(count==3)
                {
                    tx[3]=tx[2];
                    tx[2]=tx[1];
                    tx[1]=tx[0];
                    tx[0]='0';
                }  
                puts("\n\rEnter the DATA to be sent [NOTE : Max 4 DATA(Extra DATA will be Transcated)] :- ");
                count=4;
            }
            else if(ch >= 48 && ch <=57)
                tx[count++]=ch;                            // storing Product ID data in the TX[] array for sending to the cilent
            if(ch!='\r')
                putch(ch);
            ch = '\0';
        }
        else if(ch != '\0'&& flag==2)
        {
            if(ch==0)
            {
                flag=1;
                ch='\0';
                continue;
            }
            else if(ch=='\r')
            {
                if(count==5)
                {
                    tx[7]=tx[4];
                    tx[6]='0';
                    tx[5]='0';
                    tx[4]='0';
                }
                else if(count==6)
                {
                    tx[7]=tx[5];
                    tx[6]=tx[4];
                    tx[5]='0';          // When the UART interrupt occur we are going to store the value
                    tx[4]='0';
                }
                else if(count==7)
                {
                    tx[7]=tx[6];
                    tx[6]=tx[5];
                    tx[5]=tx[4];
                    tx[4]='0';
                }
                flag=1;
                tx[8]='\0';
                can_transmit();
                puts("\n\r");
            }
            else if(ch >= 48 && ch <=57)
                tx[count++]=ch;                 // storing U[dated Stock data in the TX[] array for sending to the cilent
            if(ch!='\r')
                putch(ch);
            ch = '\0';
        }  
	}
}
